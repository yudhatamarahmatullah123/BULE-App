package com.example.pale

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.example.pale.databinding.ActivitySettingBinding

class SettingActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingBinding
    private val viewModel: SettingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel.getTheme().observe(this) { isDarkMode ->
            AppCompatDelegate.setDefaultNightMode(
                if (isDarkMode) AppCompatDelegate.MODE_NIGHT_YES
                else AppCompatDelegate.MODE_NIGHT_NO
            )
            binding.switchDarkMode.isChecked = isDarkMode
            updateUIForNightMode()
        }

        binding.switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setTheme(isChecked)
            with(getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE).edit()){
                putBoolean("night_mode", isChecked)
                apply()
            }
        }

        binding.btnBack.setOnClickListener { finish() }
    }

    private fun updateUIForNightMode() {
        val isNightMode = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES
        binding.ivIconDarkMode.setImageResource(if (isNightMode) R.drawable.ic_moon else R.drawable.ic_sun)
        binding.tvDarkModeLabel.text = if (isNightMode) "Dark Mode" else "Light Mode"
        setStatusBarColor(if (isNightMode) R.color.black else R.color.white, !isNightMode)
    }
}
