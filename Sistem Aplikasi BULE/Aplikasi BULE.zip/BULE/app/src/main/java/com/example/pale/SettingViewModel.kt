package com.example.pale

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch


class SettingViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PaleRepository(application)

    fun setTheme(isDarkMode: Boolean) = viewModelScope.launch {
        repository.setTheme(isDarkMode)

    }

    fun getTheme(): LiveData<Boolean> = repository.getTheme()
}
