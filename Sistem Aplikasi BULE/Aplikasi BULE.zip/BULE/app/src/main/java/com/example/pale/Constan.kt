package com.example.pale

import androidx.datastore.preferences.core.booleanPreferencesKey

object Constan {
    const val EXTRA_USERNAME = "USERNAME"
    const val USER_DATASTORE = "USER_DATASTORE"
    val THEME_KEY = booleanPreferencesKey("THEME_SETTING")
}