package com.example.pale

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.IBinder
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.pale.databinding.FragmentNotificationBinding

class NotificationFragment : Fragment() {

    private lateinit var binding: FragmentNotificationBinding
    private var isSuhuDanger: Boolean = false
    private var isAmmoniaDanger: Boolean = false
    private var isPhAirDanger: Boolean = false
    private val mqtt: Mqtt = Mqtt() // Inisialisasi objek mqtt di sini

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentNotificationBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Start the background service
        val serviceIntent = Intent(requireContext(), DangerMonitoringService::class.java)
        requireContext().startService(serviceIntent)

        mqtt.connect(requireContext()) { topic, value ->
            when (topic) {
                Mqtt.suhu -> {
                    if (value.toDouble() < 20 || value.toDouble() > 30) {
                        isSuhuDanger = true
                        binding.tvSuhu.text = "${value.toDouble().toInt()}°C"
                        binding.cardSuhu.visibility = View.VISIBLE
                    } else {
                        isSuhuDanger = false
                        binding.cardSuhu.visibility = View.GONE
                    }
                    checkDanger()
                }
                Mqtt.ammonia -> {
                    if (value.toDouble() >= 0.8) {
                        isAmmoniaDanger = true
                        binding.tvAmonia.text = value
                        binding.cardAmmonia.visibility = View.VISIBLE
                    } else {
                        isAmmoniaDanger = false
                        binding.cardAmmonia.visibility = View.GONE
                    }
                    checkDanger()
                }
                Mqtt.phAir -> {
                    if (value.toDouble() < 6 || value.toDouble() > 9) {
                        isPhAirDanger = true
                        binding.tvPhAir.text = value
                        binding.cardPhAir.visibility = View.VISIBLE
                    } else {
                        isPhAirDanger = false
                        binding.cardPhAir.visibility = View.GONE
                    }
                    checkDanger()
                }
                Mqtt.katup -> {
                    // Update status switch berdasarkan payload
                    binding.switchKatup.isChecked = value?.lowercase() == "on"
                    binding.switchKatup.setOnCheckedChangeListener { _, isChecked ->
                        // Kirim perintah ke broker MQTT saat switch diubah
                        val payload = if (isChecked) "on" else "off"
                        mqtt.publish(Mqtt.katup, payload)
                    }
                }
            }
        }
    }

    private fun checkDanger() {
        if (isSuhuDanger || isAmmoniaDanger || isPhAirDanger) {
            showLayoutDanger()
            sendDangerNotifications()
        } else {
            hideLayoutDanger()
        }
    }

    private fun sendDangerNotifications() {
        // Send notifications for each danger condition
        if (isSuhuDanger) {
            NotificationUtils.sendDangerNotification(
                requireContext(),
                "Temperature is out of range: ${binding.tvSuhu.text}",
                1 // ID unik untuk suhu
            )
        }
        if (isAmmoniaDanger) {
            NotificationUtils.sendDangerNotification(
                requireContext(),
                "Ammonia level is too high: ${binding.tvAmonia.text}",
                2 // ID unik untuk ammonia
            )
        }
        if (isPhAirDanger) {
            NotificationUtils.sendDangerNotification(
                requireContext(),
                "pH level is out of range: ${binding.tvPhAir.text}",
                3 // ID unik untuk pH
            )
        }
    }

    private fun showLayoutDanger() {
        with(binding) {
            layoutTopDanger.visibility = View.VISIBLE
            tvTitle.visibility = View.GONE
            ivNotification.visibility = View.GONE
            tvNotification.visibility = View.GONE
            ivBackground.setImageResource(R.drawable.background_red)
            requireActivity().setStatusBarColor(android.R.color.holo_red_dark, true)
        }
    }

    private fun hideLayoutDanger() {
        with(binding) {
            layoutTopDanger.visibility = View.GONE
            tvTitle.visibility = View.VISIBLE
            ivNotification.visibility = View.VISIBLE
            tvNotification.visibility = View.VISIBLE
            ivBackground.setImageResource(R.drawable.background_blue)
            requireActivity().setStatusBarColor(R.color.primary_blue, true)
        }
    }

    // Background service to monitor danger conditions
    class DangerMonitoringService : Service() {
        private val mqtt: Mqtt = Mqtt()

        override fun onCreate() {
            super.onCreate()
            NotificationUtils.createNotificationChannel(this)

            mqtt.connect(applicationContext) { topic, value ->
                when (topic) {
                    Mqtt.suhu -> {
                        if (value.toDouble() < 20 || value.toDouble() > 30) {
                            NotificationUtils.sendDangerNotification(
                                this,
                                "Temperature is out of range: ${value.toDouble().toInt()}°C",
                                1 // ID unik untuk suhu
                            )
                        }
                    }
                    Mqtt.ammonia -> {
                        if (value.toDouble() >= 0.8) {
                            NotificationUtils.sendDangerNotification(
                                this,
                                "Ammonia level is too high: $value",
                                2 // ID unik untuk ammonia
                            )
                        }
                    }
                    Mqtt.phAir -> {
                        if (value.toDouble() < 6 || value.toDouble() > 9) {
                            NotificationUtils.sendDangerNotification(
                                this,
                                "pH level is out of range: $value",
                                3 // ID unik untuk pH
                            )
                        }
                    }
                }
            }
        }

        override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
            return START_STICKY
        }

        override fun onBind(intent: Intent?): IBinder? {
            return null
        }
    }
}
