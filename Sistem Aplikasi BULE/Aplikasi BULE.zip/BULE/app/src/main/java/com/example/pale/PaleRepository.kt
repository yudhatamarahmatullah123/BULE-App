package com.example.pale

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import kotlinx.coroutines.Dispatchers

class PaleRepository(application: Application) {

    private val settingPref = SettingPreferences.getInstance(application)

    suspend fun setTheme(isDarkMode: Boolean) {
        settingPref.setTheme(isDarkMode)
    }

    fun getTheme(): LiveData<Boolean> =
        settingPref.getTheme().asLiveData(Dispatchers.IO)
}
