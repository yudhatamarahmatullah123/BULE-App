package com.example.pale

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.example.pale.databinding.ActivityEditNameBinding

class EditNameActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditNameBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditNameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sp = getSharedPreferences(getString(R.string.app_name),
            MODE_PRIVATE
        )

        val name = sp.getString("name", "Yudhatama Gusdi Rahmatullah")
        val isNightMode = sp.getBoolean("night_mode", false)

        if (isNightMode) {
            this.setStatusBarColor(R.color.black, false)
        } else {
            this.setStatusBarColor(R.color.white, true)
        }

        binding.edtName.setText(name.orEmpty())
        binding.tvNameCount.text = name.orEmpty().length.toString()

        binding.edtName.addTextChangedListener { editable ->
            val count = editable?.count() ?: 0
            binding.tvNameCount.text = count.toString()
        }

        binding.btnSave.setOnClickListener {
            val newName = binding.edtName.text.toString()
            if (newName.isEmpty()) {
                binding.edtName.error = "Nama tidak boleh kosong"
            } else {
                val editor = sp.edit()
                editor.putString("name", newName)
                editor.apply()
                finish()
            }
        }

        binding.btnBack.setOnClickListener {
            finish()
        }
    }
}
