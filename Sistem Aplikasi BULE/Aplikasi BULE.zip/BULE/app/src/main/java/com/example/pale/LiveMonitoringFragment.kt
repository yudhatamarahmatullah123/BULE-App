import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.pale.Mqtt
import com.example.pale.R
import com.example.pale.databinding.FragmentLiveMonitoringBinding
import com.example.pale.setStatusBarColor
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

class LiveMonitoringFragment : Fragment() {

    private lateinit var binding: FragmentLiveMonitoringBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentLiveMonitoringBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Set status bar color (assuming you have this utility function)
        requireActivity().setStatusBarColor(R.color.primary_blue, true)

        // Check internet connection and handle accordingly
        if (!isInternetAvailable()) {
            showNoInternetDialog()
        } else {
            // Show progress bars initially
            showProgressBars()

            // Initialize MQTT connection
            val mqtt = Mqtt()
            mqtt.connect(requireContext()) { topic, value ->
                // Hide progress bar and show TextView once data is received
                hideProgressBar(topic)

                when (topic) {
                    Mqtt.suhu -> {
                        binding.tvSuhu.text = "${value.toDouble().toInt()}°C"
                        if (value.toDouble() < 25 || value.toDouble() > 30) {
                            binding.cardSuhu.setCardBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.holo_red_dark))
                        } else {
                            binding.cardSuhu.setCardBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.white))
                        }
                    }
                    Mqtt.ammonia -> {
                        binding.tvAmonia.text = value
                        if (value.toDouble() > 0.8) {
                            binding.cardAmmonia.setCardBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.holo_red_dark))
                        } else {
                            binding.cardAmmonia.setCardBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.white))
                        }
                    }
                    Mqtt.phAir -> {
                        binding.tvPhAir.text = value
                        if (value.toDouble() < 6 || value.toDouble() > 9) {
                            binding.cardPhAir.setCardBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.holo_red_dark))
                        } else {
                            binding.cardPhAir.setCardBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.white))
                        }
                    }
                }
            }

            // Fetch prediction data
//            fetchPredictionData()
        }
    }

    @SuppressLint("ServiceCast")
    private fun isInternetAvailable(): Boolean {
        val connectivityManager = requireContext().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkCapabilities = connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
        return networkCapabilities != null &&
                (networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                        networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))
    }

    private fun showNoInternetDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Tidak Ada Koneksi Internet")
            .setMessage("Anda belum ada internet. Yakin ingin melanjutkan?")
            .setPositiveButton("Lanjutkan") { dialog, _ ->
                // Continue the application flow (or handle as needed)
                dialog.dismiss()
            }
            .setNegativeButton("Keluar") { _, _ ->
                // Exit the application
                requireActivity().finish()
            }
            .setIcon(android.R.drawable.ic_dialog_alert)
            .show()
    }

    private fun showProgressBars() {
        binding.progressbarPhAir.visibility = View.VISIBLE
        binding.progressbarSuhu.visibility = View.VISIBLE
        binding.progressbarAmmonia.visibility = View.VISIBLE
//        binding.cardPrediction.visibility = View.GONE

        binding.tvPhAir.visibility = View.GONE
        binding.tvSuhu.visibility = View.GONE
        binding.tvAmonia.visibility = View.GONE
    }

    private fun hideProgressBar(topic: String) {
        when (topic) {
            Mqtt.suhu -> {
                binding.progressbarSuhu.visibility = View.GONE
                binding.tvSuhu.visibility = View.VISIBLE
            }
            Mqtt.ammonia -> {
                binding.progressbarAmmonia.visibility = View.GONE
                binding.tvAmonia.visibility = View.VISIBLE
            }
            Mqtt.phAir -> {
                binding.progressbarPhAir.visibility = View.GONE
                binding.tvPhAir.visibility = View.VISIBLE
            }
        }
    }

//    private fun fetchPredictionData() {
//        val client = OkHttpClient()
//        val request = Request.Builder()
//            .url("http://103.195.19.133:8080/predict")
//            .build()
//
//        client.newCall(request).enqueue(object : Callback {
//            override fun onFailure(call: Call, e: IOException) {
//                Handler(Looper.getMainLooper()).post {
//                    // Handle failure
//                    binding.tvPrediction.text = "Loading..."
//                    binding.cardPrediction.visibility = View.VISIBLE
//                }
//            }
//
//            override fun onResponse(call: Call, response: Response) {
//                response.body?.string()?.let { responseBody ->
//                    Handler(Looper.getMainLooper()).post {
//                        try {
//                            // Log the response body
//                            Log.d("LiveMonitoringFragment", "Response: $responseBody")
//
//                            val jsonObject = JSONObject(responseBody)
//                            val status = jsonObject.getInt("Status")
//                            val predictionText = when (status) {
//                                0 -> "Normal"
//                                1 -> "Anomaly Detected"
//                                else -> "Unknown"
//                            }
//
//                            binding.tvPrediction.text = "$predictionText"
//                            binding.cardPrediction.visibility = View.VISIBLE
//                        } catch (e: JSONException) {
//                            binding.tvPrediction.text = "Error parsing data"
//                            binding.cardPrediction.visibility = View.VISIBLE
//                        }
//                    }
//                }
//            }
//        })
//    }
}
