package com.example.pale

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import com.example.pale.Constan.USER_DATASTORE
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class SettingPreferences(private val context: Context) {

    private val Context.userPreferenceDataStore: DataStore<Preferences> by preferencesDataStore(name = USER_DATASTORE)

    companion object {
        private val THEME_KEY = booleanPreferencesKey("THEME_SETTING")

        @Volatile
        private var instance: SettingPreferences? = null

        fun getInstance(context: Context): SettingPreferences =
            instance ?: synchronized(this) {
                instance ?: SettingPreferences(context).also { instance = it }
            }
    }

    suspend fun setTheme(isDarkMode: Boolean) {
        context.userPreferenceDataStore.edit { preferences ->
            preferences[THEME_KEY] = isDarkMode
        }
    }

    fun getTheme(): Flow<Boolean> =
        context.userPreferenceDataStore.data.map { preferences ->
            preferences[THEME_KEY] ?: false
        }
}
